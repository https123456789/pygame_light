# pygame_light

A simple 2D light library for pygame.