class LightSource:
	def __init__(self):
		pass